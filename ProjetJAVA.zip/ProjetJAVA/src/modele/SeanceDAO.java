/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author sayco
 */
public class SeanceDAO extends DAO<Seance> {
  public SeanceDAO(Connection conn) {
    super(conn);
  }

  public boolean create(Seance obj) {
    return false;
  }

  public boolean delete(Seance obj) {
    return false;
  }
   
  public boolean update(Seance obj) {
    return false;
  }
   
  public Seance find(int id_seance) {
    Seance seance = new Seance();      
      
    try {
      ResultSet result = this.connect.createStatement(
        ResultSet.TYPE_SCROLL_INSENSITIVE,
        ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT * FROM seance WHERE id_seance = " + id_seance);
      if(result.first())
        seance = new Seance(
          id_seance,
          result.getString("semaine"),
          result.getString("date"),
          result.getString("heure_debut"),
          result.getString("heure_fin"),
          result.getString("etat"),
          result.getInt("id_cours"),
          result.getInt("id_typecrs")
        );         
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return seance;
  }
}
