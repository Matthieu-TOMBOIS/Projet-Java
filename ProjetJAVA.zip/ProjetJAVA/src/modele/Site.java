/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;

/**
 *
 * @author sayco
 */
public class Site {
  //ID du site
  private int id_site = 0;
  //Nom du site
  private String nom = "";
 
  
public Site(int id_site, String nom) {
   this.id_site = id_site;
   this.nom = nom;
  }

public Site(){};

public int getId() {
    return id_site;
  }

public void setId(int id_site) {
    this.id_site = id_site;
  }
  
public String getNom() {
    return nom;
  }

public void setNom(String nom) {
    this.nom = nom;
  }
}
