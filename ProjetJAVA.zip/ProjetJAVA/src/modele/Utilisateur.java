/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;

/**
 *
 * @author sayco
 */
public class Utilisateur {
  //ID
  private int id_utilisateur = 0;
  //Nom de l'utilisateur
  private String nom = "";
  //Prénom de l'utilisateur
  private String prenom = "";
  //Email de l'utilisateur
  private String email = "";
  //Mdp de l'utilisateur
  private String password = "";
  //Droit de l'utilisateur
  private String droit = "";
   
  public Utilisateur(int id_utilisateur, String nom, String prenom, String email, String password, String droit) {
    this.id_utilisateur = id_utilisateur;
    this.prenom = prenom;
    this.nom = nom;
    this.email = email;
    this.password = password;
    this.droit = droit;

  }
  
  public Utilisateur(){};
     
  public int getId() {
    return id_utilisateur;
  }

  public void setId(int id_utilisateur) {
    this.id_utilisateur = id_utilisateur;
  }

  public String getNom() {
    return nom;
  }

  public void setNom(String nom) {
    this.nom = nom;
  }

  public String getPrenom() {
    return prenom;
  }

  public void setPrenom(String prenom) {
    this.prenom = prenom;
  }
  
    public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
}
  
    public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    this.password = password; 
}
 
    public String getDroit() {
    return droit;
  }

  public void setDroit(String droit) {
    this.droit = droit; 
}  
  
}
