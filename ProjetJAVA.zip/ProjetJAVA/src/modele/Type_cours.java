/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;

/**
 *
 * @author sayco
 */
public class Type_cours {
  //ID du type de cours
  private int id_typecrs = 0;
  //Nom du type de cours
  private String nom = "";
 
  
public Type_cours(int id_typecrs, String nom) {
   this.id_typecrs = id_typecrs;
   this.nom = nom;
  }

public Type_cours(){};

public int getId() {
    return id_typecrs;
  }

public void setId(int id_typecrs) {
    this.id_typecrs = id_typecrs;
  }
  
public String getNom() {
    return nom;
  }

public void setNom(String nom) {
    this.nom = nom;
  }
}