/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author sayco
 */

public class UtilisateurDAO extends DAO<Utilisateur> {
  public UtilisateurDAO(Connection conn) {
    super(conn);
  }

  public boolean create(Utilisateur obj) {
    return false;
  }

  public boolean delete(Utilisateur obj) {
    return false;
  }
   
  public boolean update(Utilisateur obj) {
    return false;
  }
   
  public Utilisateur find(int id_utilisateur) {
    Utilisateur utilisateur = new Utilisateur();      
      
    try {
      ResultSet result = this.connect.createStatement(
        ResultSet.TYPE_SCROLL_INSENSITIVE,
        ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT * FROM utilisateur WHERE id_utilisateur = " + id_utilisateur);
      if(result.first())
        utilisateur = new Utilisateur(
          id_utilisateur,
          result.getString("nom"),
          result.getString("prenom"),
          result.getString("email"),
          result.getString("password"),
          result.getString("droit")
        );         
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return utilisateur;
  }
}


