/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author sayco
 */
public class EtudiantDAO extends DAO<Etudiant> {
  public EtudiantDAO(Connection conn) {
    super(conn);
  }

  public boolean create(Etudiant obj) {
    return false;
  }

  public boolean delete(Etudiant obj) {
    return false;
  }
   
  public boolean update(Etudiant obj) {
    return false;
  }
   
  public Etudiant find(int id_utilisateur) {
    Etudiant etudiant = new Etudiant();      
      
    try {
      ResultSet result = this.connect.createStatement(
        ResultSet.TYPE_SCROLL_INSENSITIVE,
        ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT * FROM etudiant WHERE id_utilisateur = " + id_utilisateur);
      if(result.first())
        etudiant = new Etudiant(
          id_utilisateur,
          result.getString("numero"),
          result.getInt("id_groupe"));       
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return etudiant;
  }
}