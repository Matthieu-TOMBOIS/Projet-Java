/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;

/**
 *
 * @author sayco
 */
public class Promotion {
  //ID Promo
  private int id_promo = 0;
  //Nom de la promotion
  private String nom = "";
 
  
public Promotion(int id_promo, String nom) {
   this.id_promo = id_promo;
   this.nom = nom;
  }

public Promotion(){};

public int getId() {
    return id_promo;
  }

public void setId(int id_promo) {
    this.id_promo = id_promo;
  }
  
public String getNom() {
    return nom;
  }

public void setNom(String nom) {
    this.nom = nom;
  }
}
  