/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;

import java.sql.Connection;

/**
 *
 * @author sayco
 */
public class TestDao {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    //Testons des utilisateurs
    DAO<Utilisateur> utilisateurDao = new UtilisateurDAO(SdzConnection.getInstance());
    for(int i = 1; i < 18; i++){
      Utilisateur utilisateur = utilisateurDao.find(i);
      System.out.println(
              " Utilisateur N° : " + utilisateur.getId()+ "\n" + 
              " Nom : " + utilisateur.getNom() + "\n" + 
              " Prenom : " + utilisateur.getPrenom() + "\n" +
              " Email : " + utilisateur.getEmail() + "\n" +
              " Password : " + utilisateur.getPassword() + "\n" +
              " Droit : " + utilisateur.getDroit() + "\n");
    }
      
    System.out.println("\n********************************\n");
    
    //Testons des cours
    DAO<Cours> coursDao = new CoursDAO(SdzConnection.getInstance());
    for(int i = 1; i < 7; i++){
      Cours cours = coursDao.find(i);
      System.out.println(
              "Cours N° : " + cours.getId()+ "\n" + 
              "Nom du cours : " + cours.getNom() + "\n");
    }
   
    System.out.println("\n********************************\n");
    
    //Testons des etudiants
    DAO<Etudiant> etudiantDao = new EtudiantDAO(SdzConnection.getInstance());
    for(int i = 6; i < 18; i++){
      Etudiant etudiant = etudiantDao.find(i);
      System.out.println(
              "N° ID Utilisateur : " + etudiant.getId1()+ "\n" +
              "N° etudiant : " + etudiant.getNumero() +"\n" +
              "N° ID groupe : " + etudiant.getId2() +"\n");
    }
        System.out.println("\n********************************\n");

    //Testons des groupes
    DAO<Groupe> groupeDao = new GroupeDAO(SdzConnection.getInstance());
    for(int i = 1; i < 7; i++){
      Groupe groupe = groupeDao.find(i);
      System.out.println(
              "N° ID groupe : " + groupe.getId1()+ "\n" + 
              "Nom du groupe : " + groupe.getNom() + "\n" +
              "Numero ID Promo : " + groupe.getId2() +"\n");
    }
        System.out.println("\n********************************\n");
        
        //Testons des promotions
    DAO<Promotion> promotionDao = new PromotionDAO(SdzConnection.getInstance());
    for(int i = 1; i < 4; i++){
      Promotion promotion = promotionDao.find(i);
      System.out.println(
              "N° ID promotion : " + promotion.getId()+ "\n" + 
              "Nom de la promotion: " + promotion.getNom() + "\n");
    }
        System.out.println("\n********************************\n");
        
        //Testons des salles
    DAO<Salle> salleDao = new SalleDAO(SdzConnection.getInstance());
    for(int i = 1; i < 11; i++){
      Salle salle = salleDao.find(i);
      System.out.println(
              "N° ID Salle : " + salle.getId1()+ "\n" + 
              "Nom de la salle : " + salle.getNom() + "\n" +
              "Capacite de la salle : " + salle.getCapacite() +  " places" + "\n" +
              "N° ID Site : " + salle.getId2()+ "\n");
    }
        System.out.println("\n********************************\n");
             
            //Testons des sites
    DAO<Site> siteDao = new SiteDAO(SdzConnection.getInstance());
    for(int i = 1; i < 6; i++){
      Site site = siteDao.find(i);
      System.out.println(
              "ID Site : " + site.getId()+ "\n" + 
              "Nom du site : " + site.getNom() + "\n");
    }
            System.out.println("\n********************************\n");
             
            //Testons des types de cours
    DAO<Type_cours> type_coursDao = new Type_coursDAO(SdzConnection.getInstance());
    for(int i = 1; i < 8; i++){
      Type_cours type_cours = type_coursDao.find(i);
      System.out.println(
              "ID du type de cours : " + type_cours.getId()+ "\n" + 
              "Intitulé du cours : " + type_cours.getNom() + "\n");
    }
    
     System.out.println("\n********************************\n");
             
    //Testons des enseignants
    DAO<Enseignant> enseignantDao = new EnseignantDAO(SdzConnection.getInstance());
    for(int i = 3; i < 6; i++){
      Enseignant enseignant = enseignantDao.find(i);
      System.out.println(
              "ID enseignant : " + enseignant.getId1()+ "\n" + 
              "ID cours : " + enseignant.getId2() + "\n");
    }
   
    System.out.println("\n********************************\n");
 
        //Testons des seances
    DAO<Seance> seanceDao = new SeanceDAO(SdzConnection.getInstance());
    for(int i = 1; i < 7; i++){
      Seance seance = seanceDao.find(i);
      System.out.println(
              " N° ID Seance : " + seance.getId1()+ "\n" + 
              " Semaine : " + seance.getSemaine() + "\n" + 
              " Date : " + seance.getDate() + "\n" +
              " Heure de debut : " + seance.getHeure_debut() + "\n" +
              " Heure de fin : " + seance.getHeure_fin() + "\n" +
              " Etat : " + seance.getEtat() + "\n" +        
              " ID Cours : " + seance.getId2() + "\n" +               
              " ID Type cours : " + seance.getId3() + "\n");
    }
}
    }

