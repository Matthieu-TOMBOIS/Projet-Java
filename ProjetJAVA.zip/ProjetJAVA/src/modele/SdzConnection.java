/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author sayco
 */
//CTRL + SHIFT + O pour générer les imports
public class SdzConnection{
  //URL de connexion
  private String url = "jdbc:mysql://localhost:3308/projet_java?zeroDateTimeBehavior=convertToNull";
  //Nom du user
  private String user = "root";
  //Mot de passe de l'utilisateur
  private String password = "";
  //Objet Connection
  private static Connection connect;
   
  //Constructeur privé
  private SdzConnection(){
    try {
      connect = DriverManager.getConnection(url, user, password);
    } catch (SQLException e) {
      e.printStackTrace();
    }
  }
   
  //Méthode qui va nous retourner notre instance et la créer si elle n'existe pas
   public static Connection getInstance(){
    if(connect == null){
      new SdzConnection();
    }
    return connect;   
  }   
}