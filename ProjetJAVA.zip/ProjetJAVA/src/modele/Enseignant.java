/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;

/**
 *
 * @author sayco
 */
public class Enseignant {
  //ID utilisateur
  private int id_utilisateur = 0;
  //ID cours
  private int id_cours = 0;
 
  
public Enseignant(int id_utilisateur, int id_cours) {
    this.id_utilisateur = id_utilisateur;
    this.id_cours = id_cours;
  }

public Enseignant(){};

public int getId1() {
    return id_utilisateur;
  }

public void setId(int id_utilisateur) {
    this.id_utilisateur = id_utilisateur;
  }
  
public int getId2() {
    return id_cours;
  }

public void setID2(int id_cours) {
    this.id_cours = id_cours;
  }

}