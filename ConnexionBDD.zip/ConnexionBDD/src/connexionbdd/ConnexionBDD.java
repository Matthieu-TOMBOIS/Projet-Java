
package connexionbdd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class ConnexionBDD {
    
    public static void main(String[] args) {    
        Connection MyConn = connecterSQL();
    }
    
    public static Connection connecterSQL(){
    try {
        // Connexion à la BDD
            //Nom de la BDD: projet_java 
            String url ="jdbc:mysql://localhost:3308/projet_java?useSSL=false";
            String user = "root";
            String password = "";
            Connection MyConn = DriverManager.getConnection(url,user,password);
            System.out.println("Connexion établie avec la BDD \n");
            
            // Creation d'un statement
            Statement myStmt = MyConn.createStatement();

            // Execution en langage SQL QUERRY
            ResultSet myRs = myStmt.executeQuery("select * from utilisateur ");  // Voir tous les utisateurs de la BDD // Select element de la table, from la table

            // Afichage
            while (myRs.next()) {
                //Test pour des informations saisis manuellement dans la BDD
                System.out.println("Numéro ID : " + myRs.getString(1)); // affiche les données par colonne 1,2,3....
                System.out.println("Email : " + myRs.getString(2));
                System.out.println("Password : " +myRs.getString(3));
                System.out.println("NOM : " + myRs.getString(4));
                System.out.println("Prenom " + myRs.getString(5));
                System.out.println("Droit Type : " + myRs.getString(6));
            }

        } catch (Exception exc) {
            exc.printStackTrace();
        }   
        return null;
    }
}
    
