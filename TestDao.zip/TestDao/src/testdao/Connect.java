/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testdao;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author sayco
 */

public class Connect {
  public static void main(String[] args) {      
    try {
        
    String url = "jdbc:mysql://localhost:3308/projet_java?zeroDateTimeBehavior=convertToNull";
    String user = "root";
    String password = "";

      Connection conn = DriverManager.getConnection(url, user, password);
      System.out.println("Connexion effectuée !");         
         
    } catch (Exception e) {
      e.printStackTrace();
    }      
  }
}