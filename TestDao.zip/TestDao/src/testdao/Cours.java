/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testdao;

/**
 *
 * @author sayco
 */
public class Cours {
  //ID du cours
  private int id_cours = 0;
  //Nom du cours
  private String nom = "";
 
  
public Cours(int id_cours, String nom) {
   this.id_cours = id_cours;
   this.nom = nom;
  }

public Cours(){};

public int getId() {
    return id_cours;
  }

public void setId(int id_cours) {
    this.id_cours = id_cours;
  }
  
public String getNom() {
    return nom;
  }

public void setNom(String nom) {
    this.nom = nom;
  }
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
}
