/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testdao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author sayco
 */
public class Type_coursDAO extends DAO<Type_cours> {
  public Type_coursDAO(Connection conn) {
    super(conn);
  }

  public boolean create(Type_cours obj) {
    return false;
  }

  public boolean delete(Type_cours obj) {
    return false;
  }
   
  public boolean update(Type_cours obj) {
    return false;
  }
   
  public Type_cours find(int id_typecrs) {
    Type_cours type_cours = new Type_cours();      
      
    try {
      ResultSet result = this.connect.createStatement(
        ResultSet.TYPE_SCROLL_INSENSITIVE,
        ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT * FROM type_cours WHERE id_typecrs = " + id_typecrs);
      if(result.first())
        type_cours = new Type_cours(
          id_typecrs,
          result.getString("nom")
        );         
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return type_cours;
  }
}