/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testdao;

/**
 *
 * @author sayco
 */
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class GroupeDAO extends DAO<Groupe> {
  public GroupeDAO(Connection conn) {
    super(conn);
  }

  public boolean create(Groupe obj) {
    return false;
  }

  public boolean delete(Groupe obj) {
    return false;
  }
   
  public boolean update(Groupe obj) {
    return false;
  }
   
  public Groupe find(int id_groupe) {
    Groupe groupe = new Groupe();      
      
    try {
      ResultSet result = this.connect.createStatement(
        ResultSet.TYPE_SCROLL_INSENSITIVE,
        ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT * FROM groupe WHERE id_groupe = " + id_groupe);
      if(result.first())
        groupe = new Groupe(
          id_groupe,
          result.getString("nom"),
          result.getInt("id_promo")
        );         
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return groupe;
  }
}
