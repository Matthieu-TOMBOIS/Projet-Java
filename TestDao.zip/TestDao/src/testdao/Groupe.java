/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testdao;

/**
 *
 * @author sayco
 */
public class Groupe {
  //ID du groupe
  private int id_groupe = 0;
  //Nom du groupe
  private String nom = "";
  // ID de la promotion
  private int id_promo = 0;
 
  
public Groupe(int id_groupe, String nom, int id_promo) {
   this.id_groupe = id_groupe;
   this.nom = nom;
   this.id_promo = id_promo;
  }

public Groupe(){};

public int getId1() {
    return id_groupe;
  }

public void setId1(int id_groupe) {
    this.id_groupe = id_groupe;
  }
  
public String getNom() {
    return nom;
  }

public void setNom(String nom) {
    this.nom = nom;
  }
public int getId2() {
    return id_promo;
  }

public void setId2(int id_promo) {
    this.id_promo = id_promo;
  }
}