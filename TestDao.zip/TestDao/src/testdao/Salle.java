/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testdao;

/**
 *
 * @author sayco
 */
public class Salle {
  //ID de la salle
  private int id_salle = 0;
  //Nom de la salle
  private String nom = "";
  //Capacite de la salle
  private String capacite = "";
  //ID du site de la salle
  private int id_site = 0;
 
  
public Salle(int id_salle, String nom, String capacite, int id_site) {
   this.id_salle = id_salle;
   this.nom = nom;
   this.capacite = capacite;
   this.id_site = id_site;
  }

public Salle(){};

public int getId1() {
    return id_salle;
  }

public void setId1(int id_salle) {
    this.id_salle = id_salle;
  }
  
public String getNom() {
    return nom;
  }

public void setNom(String nom) {
    this.nom = nom;
  }

public String getCapacite() {
    return capacite;
  }

public void setCapacite(String capacite) {
    this.capacite = capacite;
  }
public int getId2() {
    return id_site;
  }

public void setId2(int id_site) {
    this.id_site = id_site;
  }
}

