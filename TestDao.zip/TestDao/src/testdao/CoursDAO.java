/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testdao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author sayco
 */
public class CoursDAO extends DAO<Cours> {
  public CoursDAO(Connection conn) {
    super(conn);
  }

  public boolean create(Cours obj) {
    return false;
  }

  public boolean delete(Cours obj) {
    return false;
  }
   
  public boolean update(Cours obj) {
    return false;
  }
   
  public Cours find(int id_cours) {
    Cours cours = new Cours();      
      
    try {
      ResultSet result = this.connect.createStatement(
        ResultSet.TYPE_SCROLL_INSENSITIVE,
        ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT * FROM cours WHERE id_cours = " + id_cours);
      if(result.first())
        cours = new Cours(
          id_cours,
          result.getString("nom")
        );         
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return cours;
  }
}
