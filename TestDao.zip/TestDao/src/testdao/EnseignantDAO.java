/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testdao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author sayco
 */
public class EnseignantDAO extends DAO<Enseignant> {
  public EnseignantDAO(Connection conn) {
    super(conn);
  }

  public boolean create(Enseignant obj) {
    return false;
  }

  public boolean delete(Enseignant obj) {
    return false;
  }
   
  public boolean update(Enseignant obj) {
    return false;
  }
   
  public Enseignant find(int id_utilisateur) {
    Enseignant enseignant = new Enseignant();      
      
    try {
      ResultSet result = this.connect.createStatement(
        ResultSet.TYPE_SCROLL_INSENSITIVE,
        ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT * FROM enseignant WHERE id_utilisateur = " + id_utilisateur);
      if(result.first())
        enseignant = new Enseignant(
          id_utilisateur,
          result.getInt("id_cours")
        );         
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return enseignant;
  }

}