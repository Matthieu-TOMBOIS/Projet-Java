/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testdao;

/**
 *
 * @author sayco
 */
public class Seance {
  //ID Seance
  private int id_seance = 0;
  //Semaine
  private String semaine = "";
  //Prénom de l'utilisateur
  private String date = "";
  //Heure de début de seance
  private String heure_debut = "";
  //Heure de fin de seance
  private String heure_fin = "";
  //Etat de la seance
  private String etat = "";
  //ID Cours
  private int id_cours = 0;
  //ID Type de cours
  private int id_typecrs = 0;
  
  public Seance(int id_seance, String semaine, String date, String heure_debut, String heure_fin, String etat, int id_cours, int id_typecrs) {
    this.id_seance = id_seance;
    this.semaine = semaine;
    this.date = date;
    this.heure_debut = heure_debut;
    this.heure_fin = heure_fin;
    this.etat = etat;
    this.id_cours = id_cours;
    this.id_typecrs = id_typecrs;

  }
  
  public Seance(){};
     
  public int getId1() {
    return id_seance;
  }

  public void setId1(int id_seance) {
    this.id_seance = id_seance;
  }

  public String getSemaine() {
    return semaine;
  }

  public void setSemaine(String semaine) {
    this.semaine = semaine;
  }

  public String getDate() {
    return date;
  }

  public void setDate(String date) {
    this.date = date;
  }
  
    public String getHeure_debut() {
    return heure_debut;
  }

  public void setHeure_debut(String heure_debut) {
    this.heure_debut = heure_debut;
}
  
      public String getHeure_fin() {
    return heure_fin;
  }

  public void setHeure_fin(String heure_fin) {
    this.heure_fin = heure_fin;
}
  
    public String getEtat() {
    return etat;
  }

  public void setEtat(String etat) {
    this.etat = etat; 
}
 
  public int getId2() {
    return id_cours;
  }

  public void setId2(int id_cours) {
    this.id_cours = id_cours;
  }
  
  public int getId3() {
    return id_typecrs;
  }

  public void setId3(int id_typecrs) {
    this.id_typecrs = id_typecrs;
  }
}