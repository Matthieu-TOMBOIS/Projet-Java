/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testdao;

/**
 *
 * @author sayco
 */
public class Etudiant {
  //ID du cours
  private int id_utilisateur = 0;
  //Numéro étudiant
  private String numero = "";
  // ID du groupe
  private int id_groupe = 0;
    //Nom étudiant
  private String nom = "";
 
  
public Etudiant(int id_utilisateur, String numero, int id_groupe) {
   this.id_utilisateur = id_utilisateur;
   this.numero = numero;
   this.id_groupe = id_groupe;
   this.nom = nom;
  }

public Etudiant(){};

public int getId1() {
    return id_utilisateur;
  }

public void setId1(int id_utilisateur) {
    this.id_utilisateur = id_utilisateur;
  }
  
public String getNumero() {
    return numero;
  }

public void setNumero(String numero) {
    this.numero = numero;
  }
public int getId2() {
    return id_groupe;
  }

public void setId2(int id_groupe) {
    this.id_groupe = id_groupe;
  }

public String getNom() {
    return nom;
  }

public void setNom(String nom) {
    this.nom = nom;

}
}
